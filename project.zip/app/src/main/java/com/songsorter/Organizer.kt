package com.songsorter

import android.content.Context
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.storage.StorageManager
import java.io.File

class Plan(val sd: File, val hebrewDir: File, val englishDir: File, val items: List<Item>, val skipped: Int) {
    enum class Kind { ARTIST, HEBREW, ENGLISH, NEWFOLDER }
    class Item(val src: File, val dests: List<File>, val kind: Kind)
}

class Result {
    var ok = 0
    var failed = 0
    var copies = 0
    val byKind = IntArray(4)
    val handled = ArrayList<String>()
    val failedNames = ArrayList<String>()
    val touched = ArrayList<String>()
}

private val SPACES = Regex("\\s+")
private val HEB_GENRE = Regex("hebrew|israeli|mizrahi|mizrachi|ישראלי|עברי|מזרחי|ים תיכוני", RegexOption.IGNORE_CASE)
private val LEADING_NUMBER = Regex("^\\s*\\d+\\s*[.)_-]+\\s*")
private val TITLE_DASH = Regex("\\s+[-–—]\\s+")
private val BAD_FILE_CHARS = Regex("[\\\\/:*?\"<>|]")

/** Metadata read from the audio file itself. */
internal class Tags(val artists: List<String>, val others: List<String>, val genre: String)

/** Everything we know about one song that still needs sorting. */
internal class Song(
    val f: File,
    val names: List<String>,      // artist candidates, best first (incl. split "A & B" parts)
    val creatable: List<String>,  // individual artists, used for creating NEW folders
    val heText: Boolean          // Hebrew letters appear in the file name / tags
)

class Organizer(
    private val ctx: Context,
    private val internalRoot: File,
    private val log: (String) -> Unit
) {

    private val songsFolderName = "שירים"
    private val englishFolderName = "אנגלית"

    private val audioExt = setOf("mp3", "m4a", "flac", "wav", "aac", "ogg", "wma", "opus")

    // Folders on internal storage that are never scanned (system sounds, chat apps, voice notes)
    private val skipDirs = setOf(
        "android", "ringtones", "notifications", "alarms",
        "whatsapp", "recordings", "voice recorder"
    )

    // Folder / tag names that are never an artist
    private val generic: Set<String> = listOf(
        "שירים", "אנגלית", "mms", "video", "videos", "music", "download", "downloads",
        "dcim", "camera", "pictures", "images", "movies", "documents", "backup", "sounds",
        "audio", "songs", "unknown", "<unknown>", "unknown artist", "various artists",
        "new folder", "תיקייה חדשה", "מוזיקה", "android", "data", "obb", "artist",
        "לא ידוע", "אמן לא ידוע", "אמנים שונים"
    ).map { norm(it) }.toSet()

    // Every file already on the SD card, as "name|size". Songs found here are left untouched.
    private val existing = HashSet<String>()

    // ----- SD card folder index (built once per run) -----
    // full folder name (normalized) -> folders
    private val byName = HashMap<String, MutableList<File>>()
    // each "component" of a folder name ("סטטיק ובן אל" -> "סטטיק ובן אל", "סטטיק", "בן אל")
    private val strong = HashMap<String, MutableList<File>>()
    // first 2..n-1 words of a component (so "בן אל" folder... and "Ben El" finds "Ben El Tavori")
    private val weak = HashMap<String, MutableList<File>>()
    // phonetic skeletons, kept per script so Hebrew <-> English can match
    private val skHeMap = HashMap<String, MutableList<File>>()
    private val skLaMap = HashMap<String, MutableList<File>>()
    // phonetic skeleton -> known Hebrew spelling (norm), and Hebrew spelling -> display text
    private val hebNames = HashMap<String, String>()
    private val hebDisplay = HashMap<String, String>()

    init {
        for (name in KNOWN_HEBREW_ARTISTS) {
            val c = norm(name)
            val sk = skeleton(c)
            if (skeletonUsable(sk) && !hebNames.containsKey(sk)) hebNames[sk] = c
            hebDisplay[c] = name
        }
    }

    private fun key(f: File) = f.name.lowercase() + "|" + f.length()

    private fun addTo(m: HashMap<String, MutableList<File>>, k: String, d: File) {
        val l = m.getOrPut(k) { ArrayList() }
        if (!l.contains(d)) l.add(d)
    }

    // ---------- SD card ----------

    /** Finds the SD card using several methods (Android 11+ hides /storage from apps). */
    fun findSd(): File? {
        val cands = LinkedHashSet<File>()

        // Method 1: app-specific dirs on every volume, cut back to the volume root
        try {
            for (d in ctx.getExternalFilesDirs(null)) {
                if (d == null) continue
                val i = d.path.indexOf("/Android/data")
                if (i > 0) cands.add(File(d.path.substring(0, i)))
            }
        } catch (e: Exception) {
            log("שיטה 1 נכשלה: ${e.message}")
        }

        // Method 2: StorageManager volumes (Android 11+)
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val sm = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
                for (v in sm.storageVolumes) {
                    val dir = v.directory
                    if (v.isRemovable && dir != null) cands.add(dir)
                }
            } catch (e: Exception) {
                log("שיטה 2 נכשלה: ${e.message}")
            }
        }

        // Method 3: plain listing of /storage (works on older Android)
        try {
            File("/storage").listFiles()?.forEach { cands.add(it) }
        } catch (e: Exception) {
            log("שיטה 3 נכשלה: ${e.message}")
        }

        val valid = cands.filter {
            !it.path.contains("emulated") && it.name != "self" && it.isDirectory && it.listFiles() != null
        }
        log("נבדקו: " + (if (cands.isEmpty()) "אין מועמדים" else cands.joinToString { it.path }))
        return valid.firstOrNull { Regex("[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}").matches(it.name) }
            ?: valid.firstOrNull()
    }

    /** Registers one SD folder under every name it can be recognized by. */
    private fun register(dir: File) {
        val comps = LinkedHashSet<String>()
        comps.add(norm(dir.name))
        for (p in splitArtists(dir.name)) comps.add(norm(p))
        for (c in comps) {
            if (c.isEmpty() || c in generic) continue
            addTo(strong, c, dir)
            val toks = c.split(' ')
            for (n in 2 until toks.size) addTo(weak, toks.take(n).joinToString(" "), dir)
            val sk = skeleton(c)
            if (skeletonUsable(sk)) {
                if (hebrewOnly(c)) {
                    addTo(skHeMap, sk, dir)
                    if (!hebNames.containsKey(sk)) hebNames[sk] = c
                    if (!hebDisplay.containsKey(c)) hebDisplay[c] = c
                } else if (latinOnly(c)) {
                    addTo(skLaMap, sk, dir)
                }
            }
        }
    }

    /** Walks the WHOLE card: indexes every folder by name and records every file. */
    private fun indexDirs(sd: File): Map<String, MutableList<File>> {
        var count = 0
        fun walk(d: File, depth: Int) {
            if (depth > 25) return
            val kids = d.listFiles() ?: return
            for (k in kids) {
                if (!k.isDirectory) {
                    existing.add(key(k))
                    continue
                }
                val n = k.name
                if (depth == 0 && n.equals("Android", true)) continue
                if (n.startsWith(".") || n == "LOST.DIR") continue
                addTo(byName, norm(n), k)
                register(k)
                count++
                if (count % 500 == 0) log("נסרקו $count תיקיות...")
                walk(k, depth + 1)
            }
        }
        walk(sd, 0)
        log("סה\"כ נסרקו $count תיקיות בכרטיס")
        return byName
    }

    private fun findTargets(index: Map<String, MutableList<File>>): Pair<File, File> {
        val mmsList = (index[norm("MMS")] ?: emptyList()).filter {
            it.parentFile?.name.equals("video", true)
        }
        if (mmsList.isEmpty()) throw IllegalStateException("לא נמצאה התיקייה video/MMS בכרטיס")
        val mms = mmsList.firstOrNull { m ->
            m.listFiles()?.any { it.isDirectory && norm(it.name) == norm(songsFolderName) } == true
        } ?: mmsList.first()

        fun sub(name: String): File {
            val found = mms.listFiles()?.firstOrNull { it.isDirectory && norm(it.name) == norm(name) }
            if (found != null) return found
            val created = File(mms, name)
            created.mkdirs()
            log("נוצרה תיקייה: ${created.path}")
            return created
        }
        return Pair(sub(songsFolderName), sub(englishFolderName))
    }

    // ---------- Folder lookup ----------

    private fun pick(l: List<File>?, ok: (File) -> Boolean): List<File> = l?.filter(ok) ?: emptyList()

    private fun isInside(d: File, root: File): Boolean =
        d.path == root.path || d.path.startsWith(root.path + File.separator)

    /**
     * Finds existing SD folders for an artist name. Handles:
     *  - exact names,
     *  - folders named after two artists ("סטטיק ובן אל" serves "סטטיק" and "בן אל תבורי"),
     *  - a longer / shorter form of the same name ("Ben El" vs "Ben El Tavori"),
     *  - Hebrew <-> English spelling ("Tuna" vs "טונה").
     * [ok] filters out folders that must not be used for this song.
     */
    private fun findFolders(raw: String, ok: (File) -> Boolean): List<File> {
        val k = norm(raw)
        if (k.isEmpty() || k in generic) return emptyList()

        var r = pick(strong[k], ok)
        if (r.isNotEmpty()) return r
        r = pick(weak[k], ok)
        if (r.isNotEmpty()) return r

        val toks = k.split(' ')
        var n = toks.size - 1
        while (n >= 2) {
            r = pick(strong[toks.take(n).joinToString(" ")], ok)
            if (r.isNotEmpty()) return r
            n--
        }

        val sk = skeleton(k)
        if (skeletonUsable(sk)) {
            val m: HashMap<String, MutableList<File>>? =
                if (latinOnly(k)) skHeMap else if (hebrewOnly(k)) skLaMap else null
            if (m != null) {
                r = pick(m[sk], ok)
                if (r.isNotEmpty()) return r
                n = toks.size - 1
                while (n >= 2) {
                    val s2 = skeleton(toks.take(n).joinToString(" "))
                    if (skeletonUsable(s2)) {
                        r = pick(m[s2], ok)
                        if (r.isNotEmpty()) return r
                    }
                    n--
                }
            }
        }
        return emptyList()
    }

    /** One identity per artist, whatever the spelling: Latin spellings map to a known Hebrew one. */
    private fun idKey(name: String): String {
        val k = norm(name)
        if (k.isEmpty()) return k
        if (latinOnly(k)) {
            val sk = skeleton(k)
            if (skeletonUsable(sk)) {
                val h = hebNames[sk]
                if (h != null) return h
            }
        }
        return k
    }

    private fun childIgnoreCase(base: File, name: String): File? {
        val want = norm(name)
        return base.listFiles()?.firstOrNull { it.isDirectory && norm(it.name) == want }
    }

    // ---------- Artist detection ----------

    private fun readTags(f: File): Tags {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.path)
            val artists = listOfNotNull(
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)
            )
            val others = listOfNotNull(
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_COMPOSER),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_WRITER),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_AUTHOR)
            )
            val genre = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE) ?: ""
            Tags(artists, others, genre)
        } catch (e: Exception) {
            Tags(emptyList(), emptyList(), "")
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    private fun readSong(f: File): Song {
        val t = readTags(f)
        val base = f.nameWithoutExtension.replace('_', ' ').replace(LEADING_NUMBER, "").trim()
        val parts = base.split(TITLE_DASH).map { it.trim() }.filter { it.isNotEmpty() }

        // Artist candidates, best first: tags, then the file name ("Artist - Title" or "Title - Artist").
        // Each source is tried whole first, then split into its individual artists.
        val raws = ArrayList<String>()
        raws.addAll(t.artists)
        if (parts.size >= 2) {
            raws.add(parts.first())
            raws.add(parts.last())
        }
        val names = ArrayList<String>()
        val seen = HashSet<String>()
        for (raw0 in raws) {
            val raw = raw0.trim()
            if (raw.isEmpty()) continue
            val cands = listOf(raw) + splitArtists(raw)
            for (c in cands) {
                val k = norm(c)
                if (k.isEmpty() || k in generic) continue
                if (seen.add(k)) names.add(c)
            }
        }

        // Individual artists for NEW folders: tags first, then the first part of the file name.
        val creatable = ArrayList<String>()
        val seenC = HashSet<String>()
        val sources = ArrayList<String>()
        sources.addAll(t.artists)
        if (parts.size >= 2) sources.add(parts.first())
        for (raw0 in sources) {
            val raw = raw0.trim()
            if (raw.isEmpty()) continue
            val sp = splitArtists(raw)
            val list = if (sp.isEmpty()) listOf(raw) else sp
            for (c in list) {
                val k = norm(c)
                if (k.isEmpty() || k in generic) continue
                if (seenC.add(k)) creatable.add(c)
            }
        }

        val heText = hasHebrew(f.name) ||
            t.artists.any { hasHebrew(it) } ||
            t.others.any { hasHebrew(it) } ||
            HEB_GENRE.containsMatchIn(t.genre)
        return Song(f, names, creatable, heText)
    }

    private fun safeName(s: String): String =
        s.replace(Regex("[\\\\/:*?\"<>|]"), " ").replace(SPACES, " ").trim().trimEnd('.', ' ')

    // ---------- Planning ----------

    fun buildPlan(): Plan {
        val sd = findSd() ?: throw IllegalStateException("לא נמצא כרטיס זיכרון. ודא שהוא מוכנס ומותקן (ראה היומן)")
        log("כרטיס זיכרון: ${sd.path}")
        val index = indexDirs(sd)
        val (heDir, enDir) = findTargets(index)
        log("יעד עברית: ${heDir.path}")
        log("יעד אנגלית: ${enDir.path}")

        // 1) Collect every song that is not on the card yet
        val songs = ArrayList<Song>()
        var scanned = 0
        var skipped = 0
        internalRoot.walkTopDown()
            .onEnter { d ->
                d == internalRoot || !(d.name.startsWith(".") || d.name.lowercase() in skipDirs)
            }
            .forEach { f ->
                if (!f.isFile || f.extension.lowercase() !in audioExt) return@forEach
                scanned++
                if (key(f) in existing) {
                    skipped++
                    return@forEach
                }
                if (scanned % 100 == 0) log("נסרקו $scanned שירים...")
                songs.add(readSong(f))
            }

        // 2) Learn which artists are Hebrew: Hebrew spellings seen in the songs, and every
        //    artist that has at least one song with Hebrew text (e.g. "Tuna" + Hebrew title).
        for (s in songs) {
            for (n in s.creatable) {
                val k = norm(n)
                if (!hebrewOnly(k)) continue
                val sk = skeleton(k)
                if (skeletonUsable(sk) && !hebNames.containsKey(sk)) hebNames[sk] = k
                if (!hebDisplay.containsKey(k)) hebDisplay[k] = n.trim()
            }
        }
        val hebrewKeys = HashSet<String>()
        for (s in songs) {
            for (n in s.creatable) {
                val k = idKey(n)
                if (k.isNotEmpty() && (hebrewOnly(k) || s.heText)) hebrewKeys.add(k)
            }
        }
        fun isHeb(s: Song): Boolean = s.heText || s.creatable.any { idKey(it) in hebrewKeys }

        // 3) Songs whose artist already has a folder on the card
        val items = ArrayList<Plan.Item>()
        val pending = ArrayList<Song>()
        for (s in songs) {
            val heb = isHeb(s)
            // A Hebrew artist's folder inside the "אנגלית" folder is a mistake of an old run: never reuse it.
            val ok: (File) -> Boolean = { d -> !(heb && isInside(d, enDir)) }
            var dests: List<File> = emptyList()
            for (n in s.names) {
                val m = findFolders(n, ok)
                if (m.isNotEmpty()) {
                    dests = m
                    break
                }
            }
            if (dests.isNotEmpty()) {
                items.add(Plan.Item(s.f, dests, Plan.Kind.ARTIST))
            } else {
                pending.add(s)
            }
        }

        // 4) Songs with no existing artist folder: an artist with 2+ such songs gets a NEW folder
        val counts = HashMap<String, Int>()
        val display = HashMap<String, String>()
        for (s in pending) {
            val keys = LinkedHashSet<String>()
            for (n in s.creatable) {
                val k = idKey(n)
                if (k.isEmpty() || k in generic) continue
                keys.add(k)
                if (!display.containsKey(k)) {
                    display[k] = if (hebrewOnly(k)) (hebDisplay[k] ?: n.trim()) else n.trim()
                }
            }
            for (k in keys) counts[k] = (counts[k] ?: 0) + 1
        }
        val newFolders = LinkedHashSet<String>()
        for (s in pending) {
            val heb = isHeb(s)
            var ck = ""
            for (n in s.creatable) {
                val k = idKey(n)
                if (k.isEmpty() || k in generic) continue
                if ((counts[k] ?: 0) >= 2) {
                    ck = k
                    break
                }
            }
            val folderName = if (ck.isEmpty()) "" else safeName(display[ck] ?: ck)
            if (folderName.isNotEmpty()) {
                val artistIsHeb = heb || hebrewOnly(ck) || ck in hebrewKeys
                val ok: (File) -> Boolean = { d -> !(artistIsHeb && isInside(d, enDir)) }
                // Safety check: does a folder for this artist already exist anywhere on the card?
                var found = findFolders(folderName, ok)
                if (found.isEmpty()) {
                    for (n in s.creatable) {
                        val m = findFolders(n, ok)
                        if (m.isNotEmpty()) {
                            found = m
                            break
                        }
                    }
                }
                if (found.isNotEmpty()) {
                    items.add(Plan.Item(s.f, found, Plan.Kind.ARTIST))
                } else {
                    val base = if (artistIsHeb) heDir else enDir
                    val dir = childIgnoreCase(base, folderName) ?: File(base, folderName)
                    if (!dir.exists()) newFolders.add(dir.path)
                    items.add(Plan.Item(s.f, listOf(dir), Plan.Kind.NEWFOLDER))
                }
            } else if (heb) {
                items.add(Plan.Item(s.f, listOf(heDir), Plan.Kind.HEBREW))
            } else {
                items.add(Plan.Item(s.f, listOf(enDir), Plan.Kind.ENGLISH))
            }
        }
        for (p in newFolders) log("תיקייה חדשה: $p")
        log("נמצאו ${items.size} שירים לסידור, $skipped כבר קיימים בכרטיס ולא ייגעו")
        return Plan(sd, heDir, enDir, items, skipped)
    }

    // ---------- Execution ----------

    fun execute(plan: Plan, move: Boolean, progress: (Int, Int) -> Unit): Result {
        val res = Result()
        plan.items.forEachIndexed { i, item ->
            try {
                var all = true
                for (d in item.dests) {
                    if (!copyOne(item.src, d, res)) all = false
                }
                if (all) {
                    res.ok++
                    res.byKind[item.kind.ordinal]++
                    res.handled.add(item.src.name + "\n   ← " + item.dests.joinToString(", ") { it.name })
                    if (move) {
                        if (item.src.delete()) res.touched.add(item.src.path)
                        else log("לא ניתן למחוק את המקור: ${item.src.name}")
                    }
                } else {
                    res.failed++
                    res.failedNames.add(item.src.name)
                    log("נכשל: ${item.src.name} (המקור לא נמחק)")
                }
            } catch (e: Exception) {
                res.failed++
                res.failedNames.add(item.src.name)
                log("שגיאה ב-${item.src.name}: ${e.message}")
            }
            progress(i + 1, plan.items.size)
        }
        return res
    }

    /** FAT/exFAT cards reject some characters that internal storage allows. */
    private fun safeFile(name: String): String {
        val s = BAD_FILE_CHARS.replace(name, "_").trim().trimEnd('.', ' ')
        return if (s.isEmpty()) "file" else s
    }

    private fun copyOne(src: File, dir: File, res: Result): Boolean {
        var dest: File? = null
        var created = false
        return try {
            dir.mkdirs()
            val fname = safeFile(src.name)
            var d = File(dir, fname)
            if (d.exists()) {
                if (d.length() == src.length()) return true // already there
                val dot = fname.lastIndexOf('.')
                val base = if (dot > 0) fname.substring(0, dot) else fname
                val ext = if (dot > 0) fname.substring(dot) else ""
                var n = 1
                do {
                    d = File(dir, "$base ($n)$ext")
                    n++
                } while (d.exists())
            }
            dest = d
            created = true
            src.copyTo(d, overwrite = false)
            if (d.length() != src.length()) {
                d.delete()
                log("גודל לא תואם אחרי העתקה: ${src.name}")
                false
            } else {
                try {
                    d.setLastModified(src.lastModified())
                } catch (e: Exception) {
                    // not important
                }
                res.copies++
                res.touched.add(d.path)
                true
            }
        } catch (e: Exception) {
            if (created) {
                try {
                    dest?.delete()
                } catch (e2: Exception) {
                    // ignore
                }
            }
            log("שגיאה בהעתקת ${src.name} אל ${dir.name}: ${e.message}")
            false
        }
    }
}
