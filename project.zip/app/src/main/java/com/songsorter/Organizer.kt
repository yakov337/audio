package com.songsorter

import android.content.Context
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.storage.StorageManager
import java.io.File
import java.text.Normalizer

class Plan(val sd: File, val hebrewDir: File, val englishDir: File, val items: List<Item>, val skipped: Int) {
    enum class Kind { ARTIST, HEBREW, ENGLISH, NEWFOLDER }
    class Item(val src: File, val dests: List<File>, val kind: Kind)
}

class Result {
    var ok = 0
    var failed = 0
    var copies = 0
    val byKind = IntArray(4)
    val handled = ArrayList<String>()
    val failedNames = ArrayList<String>()
    val touched = ArrayList<String>()
}

private val NIQQUD = Regex("[\\u0591-\\u05C7]")
private val PUNCT = Regex("[\"'`´’‘״׳\\-_.,()\\[\\]]")
private val SPACES = Regex("\\s+")

private class Pending(val f: File, val names: List<String>, val text: String)

/** Normalizes a name so "עומר  אדם", "עומר-אדם" and "Omer Adam" compare reliably. */
fun norm(s: String): String {
    var t = Normalizer.normalize(s, Normalizer.Form.NFKC)
    t = NIQQUD.replace(t, "")
    t = PUNCT.replace(t, " ")
    t = SPACES.replace(t, " ").trim().lowercase()
    return t
}

class Organizer(
    private val ctx: Context,
    private val internalRoot: File,
    private val log: (String) -> Unit
) {

    private val songsFolderName = "שירים"
    private val englishFolderName = "אנגלית"

    private val audioExt = setOf("mp3", "m4a", "flac", "wav", "aac", "ogg", "wma", "opus")

    // Folders on internal storage that are never scanned (system sounds, chat apps, voice notes)
    private val skipDirs = setOf(
        "android", "ringtones", "notifications", "alarms",
        "whatsapp", "recordings", "voice recorder"
    )

    private val sepRegex = Regex(
        "\\s*(?:;|/|,|&|\\+|\\bfeat\\.?|\\bft\\.?|\\bx\\b)\\s*",
        RegexOption.IGNORE_CASE
    )
    private val hebrewRegex = Regex("[\\u0590-\\u05FF]")
    private val blocked = setOf(norm(songsFolderName), norm(englishFolderName))

    // Every file already on the SD card, as "name|size". Songs found here are left untouched.
    private val existing = HashSet<String>()

    private fun key(f: File) = f.name.lowercase() + "|" + f.length()

    // ---------- SD card ----------

    /** Finds the SD card using several methods (Android 11+ hides /storage from apps). */
    fun findSd(): File? {
        val cands = LinkedHashSet<File>()

        // Method 1: app-specific dirs on every volume, cut back to the volume root
        try {
            for (d in ctx.getExternalFilesDirs(null)) {
                if (d == null) continue
                val i = d.path.indexOf("/Android/data")
                if (i > 0) cands.add(File(d.path.substring(0, i)))
            }
        } catch (e: Exception) {
            log("שיטה 1 נכשלה: ${e.message}")
        }

        // Method 2: StorageManager volumes (Android 11+)
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val sm = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
                for (v in sm.storageVolumes) {
                    val dir = v.directory
                    if (v.isRemovable && dir != null) cands.add(dir)
                }
            } catch (e: Exception) {
                log("שיטה 2 נכשלה: ${e.message}")
            }
        }

        // Method 3: plain listing of /storage (works on older Android)
        try {
            File("/storage").listFiles()?.forEach { cands.add(it) }
        } catch (e: Exception) {
        }

        val valid = cands.filter {
            !it.path.contains("emulated") && it.name != "self" && it.isDirectory && it.listFiles() != null
        }
        log("נבדקו: " + (if (cands.isEmpty()) "אין מועמדים" else cands.joinToString { it.path }))
        return valid.firstOrNull { Regex("[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}").matches(it.name) }
            ?: valid.firstOrNull()
    }

    /** Walks the WHOLE card: indexes every folder by normalized name and records every file. */
    private fun indexDirs(sd: File): Map<String, MutableList<File>> {
        val map = HashMap<String, MutableList<File>>()
        var count = 0
        fun walk(d: File, depth: Int) {
            if (depth > 25) return
            val kids = d.listFiles() ?: return
            for (k in kids) {
                if (!k.isDirectory) {
                    existing.add(key(k))
                    continue
                }
                val n = k.name
                if (depth == 0 && n.equals("Android", true)) continue
                if (n.startsWith(".") || n == "LOST.DIR") continue
                map.getOrPut(norm(n)) { ArrayList() }.add(k)
                count++
                if (count % 500 == 0) log("נסרקו $count תיקיות...")
                walk(k, depth + 1)
            }
        }
        walk(sd, 0)
        log("סה\"כ נסרקו $count תיקיות בכרטיס")
        return map
    }

    private fun findTargets(index: Map<String, MutableList<File>>): Pair<File, File> {
        val mmsList = (index[norm("MMS")] ?: emptyList()).filter {
            it.parentFile?.name.equals("video", true)
        }
        if (mmsList.isEmpty()) throw IllegalStateException("לא נמצאה התיקייה video/MMS בכרטיס")
        val mms = mmsList.firstOrNull { m ->
            m.listFiles()?.any { it.isDirectory && norm(it.name) == norm(songsFolderName) } == true
        } ?: mmsList.first()

        fun sub(name: String): File {
            val found = mms.listFiles()?.firstOrNull { it.isDirectory && norm(it.name) == norm(name) }
            if (found != null) return found
            val created = File(mms, name)
            created.mkdirs()
            log("נוצרה תיקייה: ${created.path}")
            return created
        }
        return Pair(sub(songsFolderName), sub(englishFolderName))
    }

    // ---------- Artist detection ----------

    private fun tags(f: File): List<String> {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.path)
            listOfNotNull(
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)
            )
        } catch (e: Exception) {
            emptyList()
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    /** Each group = full text first, then its parts (split on & , ; feat ...). */
    private fun groups(f: File): List<List<String>> {
        val raws = ArrayList<String>()
        raws.addAll(tags(f))
        val base = f.nameWithoutExtension.replace(Regex("^\\s*\\d+\\s*[.)_-]+\\s*"), "").trim()
        val parts = base.split(Regex("\\s+[-–—]\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.size >= 2) {
            raws.add(parts.first())
            raws.add(parts.last())
        }
        return raws.map { it.trim() }.filter { it.isNotEmpty() }.distinct().map { raw ->
            listOf(raw) + raw.split(sepRegex).map { it.trim() }.filter { it.isNotEmpty() && it != raw }
        }
    }

    /** Individual artists used for creating NEW folders: tags first, then the first part of the file name. */
    private fun creatableArtists(f: File): List<String> {
        val out = ArrayList<String>()
        fun add(raw: String?) {
            if (raw.isNullOrBlank()) return
            val parts = raw.split(sepRegex).map { it.trim() }.filter { it.isNotEmpty() }
            out.addAll(if (parts.isEmpty()) listOf(raw.trim()) else parts)
        }
        for (t in tags(f)) add(t)
        val base = f.nameWithoutExtension.replace(Regex("^\\s*\\d+\\s*[.)_-]+\\s*"), "").trim()
        val p = base.split(Regex("\\s+[-–—]\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        if (p.size >= 2) add(p.first())
        return out.distinctBy { norm(it) }
    }

    private fun safeName(s: String): String =
        s.replace(Regex("[\\\\/:*?\"<>|]"), " ").replace(SPACES, " ").trim().trimEnd('.', ' ')

    // ---------- Planning ----------

    fun buildPlan(): Plan {
        val sd = findSd() ?: throw IllegalStateException("לא נמצא כרטיס זיכרון. ודא שהוא מוכנס ומותקן (ראה היומן)")
        log("כרטיס זיכרון: ${sd.path}")
        val index = indexDirs(sd)
        val (heDir, enDir) = findTargets(index)
        log("יעד עברית: ${heDir.path}")
        log("יעד אנגלית: ${enDir.path}")

        fun find(raw: String): List<File> {
            val k = norm(raw)
            if (k.isEmpty() || k in blocked) return emptyList()
            return index[k] ?: emptyList()
        }

        val items = ArrayList<Plan.Item>()
        var scanned = 0
        var skipped = 0
        val pending = ArrayList<Pending>()
        internalRoot.walkTopDown()
            .onEnter { d ->
                d == internalRoot || !(d.name.startsWith(".") || d.name.lowercase() in skipDirs)
            }
            .forEach { f ->
                if (!f.isFile || f.extension.lowercase() !in audioExt) return@forEach
                scanned++
                if (key(f) in existing) {
                    skipped++
                    return@forEach
                }
                if (scanned % 100 == 0) log("נסרקו $scanned שירים...")
                val gs = groups(f)
                // Artists are checked in order (tags first, then file name). The FIRST artist that
                // has a folder wins; if that name has several folders, all of them are used.
                var dests: List<File> = emptyList()
                search@ for (g in gs) {
                    for (name in g) {
                        val m = find(name)
                        if (m.isNotEmpty()) {
                            dests = m
                            break@search
                        }
                    }
                }
                if (dests.isNotEmpty()) {
                    items.add(Plan.Item(f, dests, Plan.Kind.ARTIST))
                } else {
                    val text = f.name + " " + gs.joinToString(" ") { it[0] }
                    pending.add(Pending(f, creatableArtists(f), text))
                }
            }

        // Songs with no existing artist folder: an artist with 2+ such songs gets a NEW folder
        // (inside שירים for Hebrew names, inside אנגלית for English names).
        val counts = HashMap<String, Int>()
        val canon = HashMap<String, String>()
        for (p in pending) {
            for (n in p.names) {
                val k = norm(n)
                if (k.isEmpty() || k in blocked) continue
                canon.getOrPut(k) { n }
            }
            for (k in p.names.map { norm(it) }.filter { it.isNotEmpty() && it !in blocked }.distinct()) {
                counts[k] = (counts[k] ?: 0) + 1
            }
        }
        for (p in pending) {
            var folder = ""
            var base = heDir
            for (n in p.names) {
                val k = norm(n)
                if (k.isEmpty() || k in blocked || (counts[k] ?: 0) < 2) continue
                val name = canon[k] ?: n
                folder = safeName(name)
                base = if (hebrewRegex.containsMatchIn(name)) heDir else enDir
                break
            }
            if (folder.isNotEmpty()) {
                items.add(Plan.Item(p.f, listOf(File(base, folder)), Plan.Kind.NEWFOLDER))
            } else if (hebrewRegex.containsMatchIn(p.text)) {
                items.add(Plan.Item(p.f, listOf(heDir), Plan.Kind.HEBREW))
            } else {
                items.add(Plan.Item(p.f, listOf(enDir), Plan.Kind.ENGLISH))
            }
        }
        log("נמצאו ${items.size} שירים לסידור, $skipped כבר קיימים בכרטיס ולא ייגעו")
        return Plan(sd, heDir, enDir, items, skipped)
    }

    // ---------- Execution ----------

    fun execute(plan: Plan, move: Boolean, progress: (Int, Int) -> Unit): Result {
        val res = Result()
        plan.items.forEachIndexed { i, item ->
            var all = true
            for (d in item.dests) {
                if (!copyOne(item.src, d, res)) all = false
            }
            if (all) {
                res.ok++
                res.byKind[item.kind.ordinal]++
                res.handled.add(item.src.name + "\n   ← " + item.dests.joinToString(", ") { it.name })
                if (move) {
                    if (item.src.delete()) res.touched.add(item.src.path)
                    else log("לא ניתן למחוק את המקור: ${item.src.name}")
                }
            } else {
                res.failed++
                res.failedNames.add(item.src.name)
                log("נכשל: ${item.src.name} (המקור לא נמחק)")
            }
            progress(i + 1, plan.items.size)
        }
        return res
    }

    private fun copyOne(src: File, dir: File, res: Result): Boolean {
        return try {
            dir.mkdirs()
            var dest = File(dir, src.name)
            if (dest.exists()) {
                if (dest.length() == src.length()) return true // already there
                val base = src.nameWithoutExtension
                val ext = src.extension
                var n = 1
                do {
                    dest = File(dir, if (ext.isEmpty()) "$base ($n)" else "$base ($n).$ext")
                    n++
                } while (dest.exists())
            }
            src.copyTo(dest, overwrite = false)
            if (dest.length() != src.length()) {
                dest.delete()
                log("גודל לא תואם אחרי העתקה: ${src.name}")
                false
            } else {
                res.copies++
                res.touched.add(dest.path)
                true
            }
        } catch (e: Exception) {
            log("שגיאה בהעתקת ${src.name} אל ${dir.name}: ${e.message}")
            false
        }
    }
}
