package com.songsorter

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private val bg = Color.parseColor("#0B1020")
    private val bgEnd = Color.parseColor("#1B1446")
    private val surface = Color.parseColor("#161C33")
    private val accent = Color.parseColor("#7C5CFF")
    private val accent2 = Color.parseColor("#22D3EE")
    private val textMain = Color.parseColor("#F1F5F9")
    private val textMuted = Color.parseColor("#94A3B8")

    private lateinit var status: TextView
    private lateinit var modeHint: TextView
    private lateinit var tabCopy: TextView
    private lateinit var tabMove: TextView
    private lateinit var btn: Button
    private lateinit var bar: ProgressBar
    private lateinit var resultCard: LinearLayout
    private lateinit var resultTitle: TextView
    private lateinit var resultNum: TextView
    private lateinit var resultLabel: TextView
    private lateinit var resultDetails: TextView
    private lateinit var listBtn: TextView
    private lateinit var scanBtn: TextView
    private var lastResult: Result? = null
    private var lastMove = false
    private lateinit var logCard: LinearLayout
    private lateinit var logView: TextView

    private var busy = false
    private var moveMode = false

    // ---------- UI helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun ui(r: () -> Unit) = runOnUiThread { r() }

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun gradient(r: Int) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(accent, accent2)).apply {
            cornerRadius = dp(r).toFloat()
        }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(surface, 22)
        setPadding(dp(20), dp(18), dp(20), dp(18))
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun lp(h: Int, top: Int) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h).apply { topMargin = dp(top) }

    // ---------- Screen ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bgEnd

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bg, bgEnd))
        }
        val wrap = FrameLayout(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(40), dp(20), dp(36))
        }
        val width = minOf(resources.displayMetrics.widthPixels, dp(640))
        wrap.addView(
            content,
            FrameLayout.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL)
        )
        scroll.addView(wrap)

        // Header
        val title = label("סדרן שירים", 36f, textMain, true).apply { gravity = Gravity.CENTER }
        content.addView(title)
        val sub = label("כל שיר מגיע לתיקיית הזמר שלו בכרטיס הזיכרון", 15f, textMuted).apply {
            gravity = Gravity.CENTER
        }
        content.addView(sub, lp(ViewGroup.LayoutParams.WRAP_CONTENT, 6))

        // Status card
        val statusCard = card()
        status = label("", 16f, textMain).apply { gravity = Gravity.CENTER }
        statusCard.addView(status)
        content.addView(statusCard, lp(ViewGroup.LayoutParams.WRAP_CONTENT, 28))

        // Mode selector
        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(surface, 20)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        tabCopy = tab("העתק") { selectMode(false) }
        tabMove = tab("העבר") { selectMode(true) }
        modeRow.addView(tabCopy, LinearLayout.LayoutParams(0, dp(52), 1f))
        modeRow.addView(tabMove, LinearLayout.LayoutParams(0, dp(52), 1f))
        content.addView(modeRow, lp(ViewGroup.LayoutParams.WRAP_CONTENT, 18))

        modeHint = label("", 13f, textMuted).apply { gravity = Gravity.CENTER }
        content.addView(modeHint, lp(ViewGroup.LayoutParams.WRAP_CONTENT, 8))

        // Main button
        btn = Button(this).apply {
            text = "סדר הכול"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setAllCaps(false)
            stateListAnimator = null
            elevation = dp(10).toFloat()
            background = RippleDrawable(ColorStateList.valueOf(Color.argb(70, 255, 255, 255)), gradient(32), null)
            setOnClickListener { start() }
        }
        content.addView(btn, lp(dp(120), 22))

        // Card scan button
        scanBtn = label("סרוק כרטיס והצג הצעות ייעול", 18f, accent2, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), accent2)
                cornerRadius = dp(24).toFloat()
            }
            setOnClickListener { startScan() }
        }
        content.addView(scanBtn, lp(dp(64), 14))

        // Progress
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(accent2)
            progressBackgroundTintList = ColorStateList.valueOf(surface)
            visibility = View.INVISIBLE
        }
        content.addView(bar, lp(dp(8), 18))

        // Result card
        resultCard = card().apply { visibility = View.GONE }
        resultTitle = label("הושלם", 16f, accent2, true).apply { gravity = Gravity.CENTER }
        resultNum = label("0", 64f, textMain, true).apply { gravity = Gravity.CENTER }
        resultLabel = label("", 20f, textMain).apply { gravity = Gravity.CENTER }
        resultDetails = label("", 15f, textMuted).apply { setLineSpacing(dp(4).toFloat(), 1f) }
        resultCard.addView(resultTitle)
        resultCard.addView(resultNum)
        resultCard.addView(resultLabel)
        resultCard.addView(resultDetails, lp(ViewGroup.LayoutParams.WRAP_CONTENT, 16))
        listBtn = label("הצג רשימת קבצים מלאה", 16f, accent2, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), accent2)
                cornerRadius = dp(18).toFloat()
            }
            setOnClickListener { showFileList() }
        }
        resultCard.addView(listBtn, lp(dp(54), 18))
        content.addView(resultCard, lp(ViewGroup.LayoutParams.WRAP_CONTENT, 14))

        // Log card
        logCard = card().apply { visibility = View.GONE }
        logCard.addView(label("יומן", 14f, accent2, true))
        logView = label("", 12f, textMuted).apply {
            setTextIsSelectable(true)
            typeface = Typeface.MONOSPACE
        }
        logCard.addView(logView, lp(ViewGroup.LayoutParams.WRAP_CONTENT, 8))
        content.addView(logCard, lp(ViewGroup.LayoutParams.WRAP_CONTENT, 14))

        setContentView(scroll)
        selectMode(false)
    }

    private fun tab(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 18f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setOnClickListener { if (!busy) onClick() }
    }

    private fun selectMode(move: Boolean) {
        moveMode = move
        styleTab(tabCopy, !move)
        styleTab(tabMove, move)
        modeHint.text = if (move) {
            "המקור יימחק רק אחרי שכל ההעתקות הצליחו"
        } else {
            "השירים יועתקו והמקור יישאר במקומו"
        }
    }

    private fun styleTab(t: TextView, selected: Boolean) {
        t.background = if (selected) gradient(16) else null
        t.setTextColor(if (selected) Color.WHITE else textMuted)
    }

    override fun onResume() {
        super.onResume()
        if (!busy) {
            status.text = if (hasPerm()) "מוכן. לחץ על \"סדר הכול\"" else "נדרשת הרשאת גישה לכל הקבצים"
        }
    }

    // ---------- Permission ----------

    private fun hasPerm(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }

    private fun askPerm() {
        if (Build.VERSION.SDK_INT >= 30) {
            Toast.makeText(this, "אשר \"גישה לכל הקבצים\" ואז חזור לאפליקציה", Toast.LENGTH_LONG).show()
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            requestPermissions(
                arrayOf(
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                ), 1
            )
        }
    }

    // ---------- Flow ----------

    private fun appendLog(msg: String) {
        logCard.visibility = View.VISIBLE
        logView.append(msg + "\n")
    }

    private fun setBusy(b: Boolean) {
        busy = b
        btn.isEnabled = !b
        btn.alpha = if (b) 0.5f else 1f
        scanBtn.isEnabled = !b
        scanBtn.alpha = if (b) 0.5f else 1f
        // keep the tablet awake while scanning / copying
        if (b) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun reset(msg: String) {
        setBusy(false)
        bar.visibility = View.INVISIBLE
        status.text = msg
    }

    /** Read-only scan of the SD card; opens the review screen with the suggestions. */
    private fun startScan() {
        if (busy) return
        if (!hasPerm()) {
            askPerm()
            return
        }
        setBusy(true)
        resultCard.visibility = View.GONE
        logView.text = ""
        logCard.visibility = View.GONE
        bar.visibility = View.VISIBLE
        bar.progress = 0
        status.text = "סורק את הכרטיס..."
        thread {
            try {
                val org = Organizer(applicationContext, Environment.getExternalStorageDirectory()) { m ->
                    ui { appendLog(m) }
                }
                val list = org.scanCard()
                ui {
                    if (list.isEmpty()) {
                        reset("הסריקה הסתיימה: אין הצעות ייעול, הכרטיס מסודר")
                    } else {
                        reset("נמצאו ${list.size} הצעות")
                        ScanHolder.org = org
                        ScanHolder.list = list
                        startActivity(Intent(this@MainActivity, ReviewActivity::class.java))
                    }
                }
            } catch (e: Exception) {
                ui {
                    appendLog("שגיאה: ${e.message}")
                    reset("שגיאה: ${e.message}")
                }
            }
        }
    }

    private fun start() {
        if (busy) return
        if (!hasPerm()) {
            askPerm()
            return
        }
        setBusy(true)
        logView.text = ""
        logCard.visibility = View.GONE
        resultCard.visibility = View.GONE
        status.text = "סורק..."
        val move = moveMode

        thread {
            try {
                val org = Organizer(applicationContext, Environment.getExternalStorageDirectory()) { m ->
                    ui { appendLog(m) }
                }
                val plan = org.buildPlan()
                ui { confirm(org, plan, move) }
            } catch (e: Exception) {
                ui {
                    appendLog("שגיאה: ${e.message}")
                    reset("שגיאה: ${e.message}")
                }
            }
        }
    }

    private fun confirm(org: Organizer, plan: Plan, move: Boolean) {
        if (plan.items.isEmpty()) {
            reset(if (plan.skipped > 0) "הכול כבר מסודר" else "לא נמצאו שירים לסידור")
            showResult(Result(), plan, move, "אין מה לסדר")
            return
        }
        val artist = plan.items.filter { it.kind == Plan.Kind.ARTIST }
        val multi = artist.count { it.dests.size > 1 }
        val nw = plan.items.filter { it.kind == Plan.Kind.NEWFOLDER }
        val newFolders = nw.map { it.dests[0].path }.distinct().size
        val he = plan.items.count { it.kind == Plan.Kind.HEBREW }
        val en = plan.items.count { it.kind == Plan.Kind.ENGLISH }
        val msg = "נמצאו ${plan.items.size} שירים לסידור\n(${plan.skipped} כבר קיימים בכרטיס ולא ייגעו)\n\n" +
            "לתיקיית זמר: ${artist.size}\n" +
            "  (מתוכם ל-2 תיקיות או יותר: $multi)\n" +
            "לתיקיות זמר חדשות שייווצרו: $newFolders (${nw.size} שירים)\n" +
            "לתיקיית שירים (עברית): $he\n" +
            "לתיקיית אנגלית: $en\n\n" +
            "פעולה: " + if (move) "העברה (המקור יימחק)" else "העתקה"

        AlertDialog.Builder(this)
            .setTitle("אישור")
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton("התחל") { _, _ -> runSort(org, plan, move) }
            .setNegativeButton("בטל") { _, _ -> reset("בוטל") }
            .show()
    }

    private fun runSort(org: Organizer, plan: Plan, move: Boolean) {
        bar.visibility = View.VISIBLE
        bar.progress = 0
        status.text = "מסדר..."
        thread {
            try {
                val res = org.execute(plan, move) { done, total ->
                    ui {
                        bar.progress = done * 100 / total
                        status.text = "מסדר... $done / $total"
                    }
                }
                if (res.touched.isNotEmpty()) {
                    try {
                        MediaScannerConnection.scanFile(applicationContext, res.touched.toTypedArray(), null, null)
                    } catch (e: Exception) {
                        ui { appendLog("סריקת מדיה נכשלה: ${e.message}") }
                    }
                }
                ui {
                    appendLog("הסתיים: ${res.ok} הצליחו, ${res.failed} נכשלו")
                    reset("הושלם")
                    showResult(res, plan, move, "הושלם")
                }
            } catch (e: Exception) {
                ui {
                    appendLog("שגיאה: ${e.message}")
                    reset("שגיאה: ${e.message}")
                }
            }
        }
    }

    private fun showResult(res: Result, plan: Plan, move: Boolean, title: String) {
        val verb = if (move) "הועברו" else "הועתקו"
        resultTitle.text = title
        resultNum.text = "${res.ok}"
        resultLabel.text = "שירים $verb"
        val sb = StringBuilder()
        sb.append("לתיקיות זמר: ${res.byKind[0]}\n")
        sb.append("לתיקיית שירים (עברית): ${res.byKind[1]}\n")
        sb.append("לתיקיית אנגלית: ${res.byKind[2]}\n")
        if (res.byKind[3] > 0) sb.append("לתיקיות זמר חדשות: ${res.byKind[3]}\n")
        sb.append("סה\"כ עותקים שנוצרו בכרטיס: ${res.copies}\n")
        sb.append("דולגו כי כבר קיימים בכרטיס: ${plan.skipped}")
        if (res.failed > 0) sb.append("\nנכשלו: ${res.failed}")
        resultDetails.text = sb.toString()
        lastResult = res
        lastMove = move
        val total = res.handled.size + res.failedNames.size
        listBtn.text = "הצג רשימת קבצים מלאה ($total)"
        listBtn.visibility = if (total > 0) View.VISIBLE else View.GONE
        resultCard.visibility = View.VISIBLE
    }

    private fun showFileList() {
        val res = lastResult ?: return
        val verb = if (lastMove) "הועברו" else "הועתקו"
        val bad = res.failedNames.sortedBy { it.lowercase() }.map { "נכשל: $it" }
        val ok = res.handled.sortedBy { it.lowercase() }
        val items = (bad + ok).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("קבצים שנכשלו / $verb (${items.size})")
            .setItems(items, null)
            .setPositiveButton("סגור", null)
            .show()
    }
}
