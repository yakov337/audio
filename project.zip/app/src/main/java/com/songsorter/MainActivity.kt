package com.songsorter

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var btn: Button
    private lateinit var moveSwitch: Switch
    private lateinit var bar: ProgressBar
    private var busy = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun ui(r: () -> Unit) = runOnUiThread { r() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "סדרן שירים"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
        }
        root.addView(title)

        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(status)

        moveSwitch = Switch(this).apply {
            text = "העבר (מוחק מהמקור אחרי העתקה מוצלחת). כבוי = העתק בלבד"
            textSize = 18f
            setPadding(0, dp(12), 0, dp(12))
        }
        root.addView(moveSwitch)

        btn = Button(this).apply {
            text = "סדר הכול"
            textSize = 28f
            setOnClickListener { start() }
        }
        root.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(110)))

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.INVISIBLE
        }
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        logView = TextView(this).apply {
            textSize = 14f
            setTextIsSelectable(true)
        }
        scroll = ScrollView(this).apply { addView(logView) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (!busy) {
            status.text = if (hasPerm()) "מוכן. לחץ על \"סדר הכול\"" else "נדרשת הרשאת גישה לכל הקבצים"
        }
    }

    // ---------- Permission ----------

    private fun hasPerm(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }

    private fun askPerm() {
        if (Build.VERSION.SDK_INT >= 30) {
            Toast.makeText(this, "אשר \"גישה לכל הקבצים\" ואז חזור לאפליקציה", Toast.LENGTH_LONG).show()
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            requestPermissions(
                arrayOf(
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                ), 1
            )
        }
    }

    // ---------- Flow ----------

    private fun appendLog(msg: String) {
        logView.append(msg + "\n")
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun reset(msg: String) {
        busy = false
        btn.isEnabled = true
        bar.visibility = View.INVISIBLE
        status.text = msg
    }

    private fun start() {
        if (busy) return
        if (!hasPerm()) {
            askPerm()
            return
        }
        busy = true
        btn.isEnabled = false
        logView.text = ""
        status.text = "סורק..."
        val move = moveSwitch.isChecked

        thread {
            try {
                val org = Organizer(Environment.getExternalStorageDirectory()) { m -> ui { appendLog(m) } }
                val plan = org.buildPlan()
                ui { confirm(org, plan, move) }
            } catch (e: Exception) {
                ui {
                    appendLog("שגיאה: ${e.message}")
                    reset("שגיאה: ${e.message}")
                }
            }
        }
    }

    private fun confirm(org: Organizer, plan: Plan, move: Boolean) {
        if (plan.items.isEmpty()) {
            reset(if (plan.skipped > 0) "כל ${plan.skipped} השירים כבר קיימים בכרטיס, אין מה לסדר" else "לא נמצאו שירים לסידור")
            return
        }
        val artist = plan.items.filter { it.kind == Plan.Kind.ARTIST }
        val multi = artist.count { it.dests.size > 1 }
        val he = plan.items.count { it.kind == Plan.Kind.HEBREW }
        val en = plan.items.count { it.kind == Plan.Kind.ENGLISH }
        val msg = "נמצאו ${plan.items.size} שירים לסידור\n(${plan.skipped} כבר קיימים בכרטיס ולא ייגעו)\n\n" +
            "לתיקיית זמר: ${artist.size}\n" +
            "  (מתוכם ל-2 תיקיות או יותר: $multi)\n" +
            "לתיקיית שירים (עברית): $he\n" +
            "לתיקיית אנגלית: $en\n\n" +
            "פעולה: " + if (move) "העברה (המקור יימחק)" else "העתקה"

        AlertDialog.Builder(this)
            .setTitle("אישור")
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton("התחל") { _, _ -> runSort(org, plan, move) }
            .setNegativeButton("בטל") { _, _ -> reset("בוטל") }
            .show()
    }

    private fun runSort(org: Organizer, plan: Plan, move: Boolean) {
        bar.visibility = View.VISIBLE
        bar.progress = 0
        status.text = "מסדר..."
        thread {
            val res = org.execute(plan, move) { done, total ->
                ui {
                    bar.progress = done * 100 / total
                    status.text = "מסדר... $done / $total"
                }
            }
            MediaScannerConnection.scanFile(this, res.touched.toTypedArray(), null, null)
            ui {
                val summary = "הסתיים: ${res.ok} הצליחו, ${res.failed} נכשלו"
                appendLog(summary)
                reset(summary)
            }
        }
    }
}
