package com.songsorter

import android.content.Context
import java.io.File

class UndoResult {
    var restored = 0
    var failed = 0
    val failedNames = ArrayList<String>()
    val touched = ArrayList<String>()
}

/**
 * Remembers what the LAST copy / move run did, so it can be undone.
 * Journal lines (tab separated):
 *   C  dest                 a file we copied (undo: delete it)
 *   M  src  dest [dest...]  a file we moved (undo: put it back at src, delete extra copies)
 *   R  src  dest            a file moved although an identical one already existed at dest
 *                           (undo: copy it back to src, keep dest)
 *   D  dir                  a folder we created (undo: delete it if it is empty)
 */
object UndoLog {

    private fun file(ctx: Context) = File(ctx.filesDir, "last_operation.txt")

    fun stamp(): String =
        java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date())

    private fun isFileEntry(e: String) = e.startsWith("C\t") || e.startsWith("M\t") || e.startsWith("R\t")

    /** Saves the journal of the run that just finished (replaces the previous one). */
    fun save(ctx: Context, title: String, journal: List<String>) {
        val clean = journal.filter { !it.contains('\n') }
        if (clean.none { isFileEntry(it) }) return
        try {
            file(ctx).writeText(title + "\n" + clean.joinToString("\n"), Charsets.UTF_8)
        } catch (e: Exception) {
            // undo is a convenience; never break the run because of it
        }
    }

    private fun load(ctx: Context): Pair<String, List<String>>? {
        val f = file(ctx)
        if (!f.exists()) return null
        return try {
            val lines = f.readText(Charsets.UTF_8).split("\n")
            if (lines.size < 2) null else Pair(lines[0], lines.drop(1).filter { it.isNotEmpty() })
        } catch (e: Exception) {
            null
        }
    }

    /** Text describing the last operation, or null when there is nothing to undo. */
    fun summary(ctx: Context): String? {
        val d = load(ctx) ?: return null
        val copies = d.second.count { it.startsWith("C\t") }
        val moves = d.second.count { it.startsWith("M\t") || it.startsWith("R\t") }
        if (copies == 0 && moves == 0) return null
        val sb = StringBuilder(d.first)
        if (copies > 0) sb.append("\nקבצים שהועתקו (יימחקו): $copies")
        if (moves > 0) sb.append("\nקבצים שהועברו (יוחזרו למקום): $moves")
        return sb.toString()
    }

    fun clear(ctx: Context) {
        try {
            file(ctx).delete()
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun copyBack(from: File, to: File): Boolean {
        to.parentFile?.mkdirs()
        from.copyTo(to, overwrite = false)
        if (to.length() != from.length()) {
            to.delete()
            return false
        }
        return true
    }

    /** Puts a moved file back. [keepDests]: the destination held a pre-existing file, do not delete it. */
    private fun restore(src: File, dests: List<File>, keepDests: Boolean, res: UndoResult): Boolean {
        val first = dests.firstOrNull { it.exists() } ?: return false
        if (src.exists()) {
            // something is already at the original place: only fine if it is the same file
            if (src.length() != first.length()) return false
        } else if (keepDests) {
            if (!copyBack(first, src)) return false
        } else {
            src.parentFile?.mkdirs()
            if (!first.renameTo(src)) {
                if (!copyBack(first, src)) return false
                if (!first.delete()) return false
            }
        }
        res.touched.add(src.path)
        if (!keepDests) {
            for (d in dests) {
                if (d.exists()) {
                    if (d.delete()) res.touched.add(d.path)
                } else {
                    res.touched.add(d.path)
                }
            }
        }
        return true
    }

    fun undo(ctx: Context, log: (String) -> Unit, progress: (Int, Int) -> Unit): UndoResult {
        val data = load(ctx) ?: throw IllegalStateException("אין פעולה לביטול")
        val files = data.second.filter { isFileEntry(it) }.reversed()
        val dirs = data.second.filter { it.startsWith("D\t") }.reversed()
        val res = UndoResult()
        var done = 0
        for (e in files) {
            val p = e.split("\t")
            var ok = false
            var name = p.getOrElse(1) { "" }
            try {
                when (p[0]) {
                    "C" -> {
                        val f = File(p[1])
                        ok = if (f.exists()) f.delete() else true
                        if (ok) res.touched.add(f.path)
                    }
                    "M" -> {
                        val src = File(p[1])
                        name = src.name
                        ok = restore(src, p.drop(2).map { File(it) }, false, res)
                    }
                    "R" -> {
                        val src = File(p[1])
                        name = src.name
                        ok = if (p.size >= 3) restore(src, listOf(File(p[2])), true, res) else false
                    }
                }
            } catch (ex: Exception) {
                log("שגיאה בביטול ${File(name).name}: ${ex.message}")
                ok = false
            }
            if (ok) {
                res.restored++
            } else {
                res.failed++
                res.failedNames.add(File(name).name)
            }
            done++
            progress(done, files.size)
        }
        // folders we created: remove them if they are empty now (deepest first)
        for (d in dirs) {
            try {
                File(d.substring(2)).delete()
            } catch (ex: Exception) {
                // ignore
            }
        }
        if (res.failed == 0) clear(ctx)
        return res
    }
}
