package com.songsorter

import java.text.Normalizer

// ---------------------------------------------------------------------------
// Pure name helpers (no Android dependencies): normalization, splitting of
// "A & B" artist strings, Hebrew <-> English matching.
// ---------------------------------------------------------------------------

private val NIQQUD = Regex("[\\u0591-\\u05C7]")
private val DROP_CHARS = Regex("[\"'`´’‘״׳]")
private val PUNCT = Regex("[\\-_.,()\\[\\]־–—]")
private val SPACES = Regex("\\s+")
private val HEBREW = Regex("[\\u0590-\\u05FF]")
private val LATIN = Regex("[A-Za-z]")

// Separators between two artists: ; / , & + feat ft x
private val SEP = Regex(
    "\\s*(?:;|/|,|&|\\+|\\bfeat\\.?|\\bft\\.?|\\bx\\b)\\s*",
    RegexOption.IGNORE_CASE
)

// Hebrew "and": "סטטיק ובן אל", "סטטיק ו בן אל", "סטטיק ו-בן אל"
private val HE_CONJ = Regex("\\s+ו(?:\\s+|[-־])?(?=[\\u05D0-\\u05EA]{2})")

/** Normalizes a name so "עומר  אדם", "עומר-אדם" and "Omer Adam" compare reliably. */
fun norm(s: String): String {
    var t = Normalizer.normalize(s, Normalizer.Form.NFKC)
    t = NIQQUD.replace(t, "")
    t = DROP_CHARS.replace(t, "")
    t = PUNCT.replace(t, " ")
    t = SPACES.replace(t, " ").trim().lowercase()
    return t
}

fun hasHebrew(s: String): Boolean = HEBREW.containsMatchIn(s)
fun hasLatin(s: String): Boolean = LATIN.containsMatchIn(s)
fun hebrewOnly(s: String): Boolean = hasHebrew(s) && !hasLatin(s)
fun latinOnly(s: String): Boolean = hasLatin(s) && !hasHebrew(s)

/** "Static & Ben El" -> [Static, Ben El];  "סטטיק ובן אל" -> [סטטיק, בן אל]. */
fun splitArtists(raw: String): List<String> {
    val out = ArrayList<String>()
    for (p in raw.split(SEP)) {
        for (q in p.split(HE_CONJ)) {
            val t = q.trim()
            if (t.isNotEmpty()) out.add(t)
        }
    }
    return out
}

// ---------------------------------------------------------------------------
// Phonetic "skeleton": lets "Tuna" match "טונה", "Static" match "סטטיק",
// "Omer Adam" match "עומר אדם". Vowels are dropped, similar consonants are
// merged, a final -a/-e/-ה is kept as a marker (so Dan != Dana).
// ---------------------------------------------------------------------------

private fun heLetter(c: Char): Char = when (c) {
    'ב' -> 'b'
    'ג' -> 'g'
    'ד' -> 'd'
    'ז', 'צ', 'ץ' -> 'z'
    'ח' -> 'h'
    'ט', 'ת' -> 't'
    'כ', 'ך', 'ק' -> 'k'
    'ל' -> 'l'
    'מ', 'ם' -> 'm'
    'נ', 'ן' -> 'n'
    'ס', 'ש' -> 's'
    'פ', 'ף' -> 'p'
    'ר' -> 'r'
    else -> ' '
}

private fun laLetter(c: Char): Char = when (c) {
    'b', 'v', 'w' -> 'b'
    'c', 'k', 'q' -> 'k'
    'd' -> 'd'
    'f', 'p' -> 'p'
    'g', 'j' -> 'g'
    'h' -> 'h'
    'l' -> 'l'
    'm' -> 'm'
    'n' -> 'n'
    'r' -> 'r'
    's' -> 's'
    't' -> 't'
    'z' -> 'z'
    else -> ' '
}

private fun appendSk(sb: StringBuilder, m: Char) {
    if (m != ' ' && (sb.isEmpty() || sb[sb.length - 1] != m)) sb.append(m)
}

private fun skHe(tok: String): String {
    val sb = StringBuilder()
    for (i in tok.indices) {
        val c = tok[i]
        val m: Char = if (c == 'ה') {
            if (i == tok.length - 1 && tok.length >= 2) 'a' else 'h'
        } else {
            heLetter(c)
        }
        appendSk(sb, m)
    }
    return sb.toString()
}

private fun skLa(tok: String): String {
    val raw = StringBuilder()
    for (ch in tok) {
        if (ch in 'a'..'z') raw.append(ch)
    }
    var t = raw.toString()
    if (t.isEmpty()) return ""
    t = t.replace("sh", "s").replace("ch", "h").replace("kh", "h").replace("th", "t")
        .replace("ph", "p").replace("ck", "k").replace("tz", "z").replace("ts", "z")
        .replace("zh", "z")
    var marker = false
    if (t.length >= 2) {
        if (t.endsWith("ah") || t.endsWith("eh")) {
            marker = true
            t = t.substring(0, t.length - 1)
        } else if (t.endsWith("a") || t.endsWith("e")) {
            marker = true
        }
    }
    val sb = StringBuilder()
    for (c in t) {
        if (c == 'x') {
            appendSk(sb, 'k')
            appendSk(sb, 's')
        } else {
            appendSk(sb, laLetter(c))
        }
    }
    if (marker) sb.append('a')
    return sb.toString()
}

/** Expects an already-normalized (lowercase) name. */
fun skeleton(name: String): String {
    val toks = ArrayList<String>()
    for (tok in name.split(' ')) {
        if (tok.isEmpty()) continue
        val s = if (hasHebrew(tok)) skHe(tok) else skLa(tok)
        if (s.isNotEmpty()) toks.add(s)
    }
    return toks.joinToString(" ")
}

/** Skeletons shorter than 3 letters are too ambiguous to trust. */
fun skeletonUsable(sk: String): Boolean = sk.replace(" ", "").length >= 3

/**
 * Well-known Israeli artists. If a song's artist matches one of these (even when
 * written in English letters) the song is treated as Hebrew, and new folders get
 * the Hebrew spelling.
 */
val KNOWN_HEBREW_ARTISTS: List<String> = listOf(
    "טונה", "סטטיק", "בן אל", "בן אל תבורי", "עומר אדם", "אייל גולן", "נועה קירל",
    "איתי לוי", "עדן חסון", "עדן בן זקן", "סאבלימינל", "שלמה ארצי", "ברי סחרוף",
    "אריק איינשטיין", "שרית חדד", "משה פרץ", "מאור אדרי", "דודו אהרון", "אביב גפן",
    "עידן רייכל", "נתן גושן", "שי גבסו", "אגם בוחבוט", "הדג נחש", "נסרין קדרי",
    "אנה זק", "יובל דיין", "ישי ריבו", "אהוד בנאי", "מתי כספי", "יהורם גאון",
    "זוהר ארגוב", "חיים משה", "אביתר בנאי", "אושר כהן", "ליאור נרקיס", "רמי קלינשטיין",
    "קובי פרץ", "עידן עמדי", "נטע ברזילי", "מוש בן ארי", "צביקה פיק", "גידי גוב",
    "שלמה גרוניך", "רן דנקר", "קובי אפללו", "שלומי שבת", "רוני דלומי", "אניה בוקשטיין"
)
