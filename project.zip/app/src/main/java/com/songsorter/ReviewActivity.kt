package com.songsorter

import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.MediaScannerConnection
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

/** Passes the scan result from the home screen to the review screen. */
object ScanHolder {
    var org: Organizer? = null
    var list: List<Suggestion> = emptyList()
}

/** Shows the scan suggestions; only the ticked ones are carried out. */
class ReviewActivity : Activity() {

    private val bg = Color.parseColor("#0B1020")
    private val bgEnd = Color.parseColor("#1B1446")
    private val surface = Color.parseColor("#161C33")
    private val accent = Color.parseColor("#7C5CFF")
    private val accent2 = Color.parseColor("#22D3EE")
    private val warn = Color.parseColor("#F59E0B")
    private val textMain = Color.parseColor("#F1F5F9")
    private val textMuted = Color.parseColor("#94A3B8")

    private var items: List<Suggestion> = emptyList()
    private var checked = BooleanArray(0)
    private var busy = false
    private lateinit var applyBtn: TextView
    private lateinit var bar: ProgressBar
    private lateinit var adapter: BaseAdapter

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun gradient(r: Int) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(accent, accent2)).apply {
            cornerRadius = dp(r).toFloat()
        }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun outlined(t: String, onClick: () -> Unit) = label(t, 15f, accent2, true).apply {
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke(dp(2), accent2)
            cornerRadius = dp(16).toFloat()
        }
        setOnClickListener { onClick() }
    }

    private fun kindLabel(k: Suggestion.Kind) = when (k) {
        Suggestion.Kind.NEWFOLDER -> "תיקייה חדשה"
        Suggestion.Kind.MOVE -> "העברה"
        Suggestion.Kind.DELETE -> "קובץ כפול למחיקה"
    }

    private fun kindColor(k: Suggestion.Kind) = when (k) {
        Suggestion.Kind.NEWFOLDER -> accent2
        Suggestion.Kind.MOVE -> accent
        Suggestion.Kind.DELETE -> warn
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bgEnd
        items = ScanHolder.list
        if (items.isEmpty() || ScanHolder.org == null) {
            finish()
            return
        }
        checked = BooleanArray(items.size)

        val root = FrameLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bg, bgEnd))
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(32), dp(16), dp(20))
        }
        val width = minOf(resources.displayMetrics.widthPixels, dp(720))
        root.addView(
            content,
            FrameLayout.LayoutParams(width, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER_HORIZONTAL)
        )

        content.addView(label("הצעות ייעול", 30f, textMain, true).apply { gravity = Gravity.CENTER })
        content.addView(
            label("סמן את ההצעות שברצונך ליישם. רק הן יבוצעו.", 14f, textMuted).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(4)
            }
        )

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(outlined("בחר הכול") { setAll(true) }, LinearLayout.LayoutParams(0, dp(44), 1f).apply {
            marginEnd = dp(8)
        })
        row.addView(outlined("נקה הכול") { setAll(false) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        content.addView(
            row,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(14)
                bottomMargin = dp(10)
            }
        )

        val list = ListView(this).apply {
            divider = ColorDrawable(Color.TRANSPARENT)
            dividerHeight = dp(8)
            setSelector(ColorDrawable(Color.TRANSPARENT))
        }
        adapter = object : BaseAdapter() {
            override fun getCount(): Int = items.size
            override fun getItem(position: Int): Any = items[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val sg = items[position]
                val r = LinearLayout(this@ReviewActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    background = rounded(surface, 18)
                    setPadding(dp(14), dp(12), dp(14), dp(12))
                }
                val cb = CheckBox(this@ReviewActivity).apply {
                    isChecked = checked[position]
                    isFocusable = false
                    isClickable = false
                    buttonTintList = ColorStateList.valueOf(accent2)
                }
                val col = LinearLayout(this@ReviewActivity).apply { orientation = LinearLayout.VERTICAL }
                col.addView(label(kindLabel(sg.kind), 12f, kindColor(sg.kind), true))
                col.addView(
                    label(sg.title, 16f, textMain, true),
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        topMargin = dp(2)
                    }
                )
                col.addView(
                    label(sg.detail, 13f, textMuted).apply { setLineSpacing(dp(3).toFloat(), 1f) },
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        topMargin = dp(6)
                    }
                )
                r.addView(cb)
                r.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(8)
                })
                return r
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            if (!busy) {
                checked[pos] = !checked[pos]
                adapter.notifyDataSetChanged()
                updateApply()
            }
        }
        content.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(accent2)
            progressBackgroundTintList = ColorStateList.valueOf(surface)
            visibility = View.INVISIBLE
        }
        content.addView(
            bar,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)).apply { topMargin = dp(10) }
        )

        applyBtn = label("", 20f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = RippleDrawable(ColorStateList.valueOf(Color.argb(70, 255, 255, 255)), gradient(26), null)
            setOnClickListener { askApply() }
        }
        content.addView(
            applyBtn,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)).apply { topMargin = dp(10) }
        )

        setContentView(root)
        updateApply()
    }

    private fun setAll(v: Boolean) {
        if (busy) return
        for (i in checked.indices) checked[i] = v
        adapter.notifyDataSetChanged()
        updateApply()
    }

    private fun selected(): List<Suggestion> {
        val out = ArrayList<Suggestion>()
        for (i in items.indices) if (checked[i]) out.add(items[i])
        return out
    }

    private fun updateApply() {
        val n = selected().size
        applyBtn.text = if (n == 0) "סמן הצעות לביצוע" else "בצע את המסומנות ($n)"
        applyBtn.alpha = if (n == 0 || busy) 0.5f else 1f
    }

    private fun askApply() {
        if (busy) return
        val sel = selected()
        if (sel.isEmpty()) {
            Toast.makeText(this, "לא סומנה אף הצעה", Toast.LENGTH_SHORT).show()
            return
        }
        val folders = sel.count { it.kind == Suggestion.Kind.NEWFOLDER }
        val moves = sel.filter { it.kind != Suggestion.Kind.DELETE }.sumOf { it.files.size }
        val dels = sel.count { it.kind == Suggestion.Kind.DELETE }
        val msg = StringBuilder()
        if (folders > 0) msg.append("תיקיות חדשות: $folders\n")
        if (moves > 0) msg.append("שירים שיועברו: $moves\n")
        if (dels > 0) msg.append("קבצים כפולים שיימחקו: $dels\n")
        msg.append("\nרק מה שסומן יבוצע. להמשיך?")
        AlertDialog.Builder(this)
            .setTitle("אישור ביצוע")
            .setMessage(msg.toString())
            .setPositiveButton("בצע") { _, _ -> runApply(sel) }
            .setNegativeButton("בטל", null)
            .show()
    }

    private fun runApply(sel: List<Suggestion>) {
        val org = ScanHolder.org ?: return
        busy = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        bar.visibility = View.VISIBLE
        bar.progress = 0
        applyBtn.alpha = 0.5f
        thread {
            try {
                val res = org.applySuggestions(sel) { done, total ->
                    runOnUiThread {
                        bar.progress = if (total > 0) done * 100 / total else 100
                        applyBtn.text = "מבצע... $done / $total"
                    }
                }
                if (res.touched.isNotEmpty()) {
                    try {
                        MediaScannerConnection.scanFile(applicationContext, res.touched.toTypedArray(), null, null)
                    } catch (e: Exception) {
                        // not important
                    }
                }
                runOnUiThread { finished(res, null) }
            } catch (e: Exception) {
                runOnUiThread { finished(null, e.message) }
            }
        }
    }

    private fun finished(res: Result?, error: String?) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val msg = StringBuilder()
        if (res != null) {
            msg.append("הצליחו: ${res.ok}\nנכשלו: ${res.failed}")
            if (res.failedNames.isNotEmpty()) {
                msg.append("\n\nלא בוצעו:\n")
                msg.append(res.failedNames.take(15).joinToString("\n"))
                if (res.failedNames.size > 15) msg.append("\nועוד ${res.failedNames.size - 15}...")
            }
        } else {
            msg.append("שגיאה: ${error ?: ""}")
        }
        ScanHolder.org = null
        ScanHolder.list = emptyList()
        AlertDialog.Builder(this)
            .setTitle("הסתיים")
            .setMessage(msg.toString())
            .setCancelable(false)
            .setPositiveButton("סגור") { _, _ -> finish() }
            .show()
    }
}
