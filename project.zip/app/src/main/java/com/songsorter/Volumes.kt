package com.songsorter

import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.storage.StorageManager
import java.io.File

/** A removable storage volume (SD card in the device, or a card/disk on a USB adapter). */
class Vol(val dir: File, val desc: String, val usbGuess: Boolean)

/**
 * Lists mounted removable volumes. A volume whose system name mentions "USB" or "OTG" is
 * guessed to be the USB adapter; when that is not clear the app asks the user.
 */
fun listRemovable(ctx: Context): List<Vol> {
    val out = LinkedHashMap<String, Vol>()
    if (Build.VERSION.SDK_INT >= 30) {
        try {
            val sm = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
            for (v in sm.storageVolumes) {
                val dir = v.directory ?: continue
                if (!v.isRemovable) continue
                if (v.state != Environment.MEDIA_MOUNTED) continue
                val desc = try {
                    v.getDescription(ctx) ?: dir.name
                } catch (e: Exception) {
                    dir.name
                }
                val usb = desc.contains("usb", true) || desc.contains("otg", true)
                out[dir.path] = Vol(dir, desc, usb)
            }
        } catch (e: Exception) {
            // fall through to the plain /storage listing
        }
    }
    if (out.isEmpty()) {
        try {
            val kids = File("/storage").listFiles()
            if (kids != null) {
                for (d in kids) {
                    if (d.name == "emulated" || d.name == "self") continue
                    if (d.isDirectory && d.listFiles() != null) out[d.path] = Vol(d, d.name, false)
                }
            }
        } catch (e: Exception) {
            // ignore
        }
    }
    return out.values.toList()
}
